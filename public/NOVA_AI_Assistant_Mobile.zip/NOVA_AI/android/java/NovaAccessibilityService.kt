package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter

/**
 * NOVA AI Full Accessibility Service
 * Controls phone screen, taps buttons, auto-scrolls TikTok/YouTube,
 * takes screenshots, locks phone, and opens power dialog.
 */
class NovaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: NovaAccessibilityService? = null
        const val ACTION_TAP = "com.nova.assistant.ACTION_TAP"
        const val ACTION_SCROLL = "com.nova.assistant.ACTION_SCROLL"
        const val ACTION_SCREENSHOT = "com.nova.assistant.ACTION_SCREENSHOT"
        const val ACTION_LOCK = "com.nova.assistant.ACTION_LOCK"
        const val ACTION_POWER = "com.nova.assistant.ACTION_POWER"
        const val ACTION_NOTIFICATIONS = "com.nova.assistant.ACTION_NOTIFICATIONS"
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_SCROLL -> scrollForward()
                ACTION_SCREENSHOT -> takeDeviceScreenshot()
                ACTION_LOCK -> lockDevice()
                ACTION_POWER -> openPowerMenu()
                ACTION_NOTIFICATIONS -> openNotifications()
                ACTION_TAP -> {
                    val targetText = intent.getStringExtra("target_text")
                    if (!targetText.isNullOrEmpty()) {
                        clickNodeByText(targetText)
                    }
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val filter = IntentFilter().apply {
            addAction(ACTION_TAP)
            addAction(ACTION_SCROLL)
            addAction(ACTION_SCREENSHOT)
            addAction(ACTION_LOCK)
            addAction(ACTION_POWER)
            addAction(ACTION_NOTIFICATIONS)
        }
        registerReceiver(receiver, filter)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Read screen events when needed for context analysis
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {}
    }

    // --- ACCESSIBILITY ACTION IMPLEMENTATIONS ---

    fun lockDevice(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    }

    fun openPowerMenu(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
    }

    fun takeDeviceScreenshot(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
    }

    fun openNotifications(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    fun openQuickSettings(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    }

    // Auto-Scroll TikTok, Reels, or Shorts
    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findScrollableNode(root)
        return scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    }

    // Click button on screen by text
    fun clickNodeByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            if (node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            var parent = node.parent
            while (parent != null) {
                if (parent.isClickable) {
                    return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                parent = parent.parent
            }
        }
        return false
    }

    // Dispatch physical swipe gesture on screen
    fun performSwipeUp(startX: Float, startY: Float, endX: Float, endY: Float) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findScrollableNode(child)
            if (found != null) return found
        }
        return null
    }
}